DW3CER - 0% Original

Untouched game-generated initial save. Zero stage clears and zero Musou clears; nine officers are naturally available. Includes content naturally granted by the installed Steam edition.

These percentages are package labels, not measurements of Steam achievements or every game challenge.
Windows Steam App 3841510; tested build 25630985; executable 1.0.2.0.

Installation
1. Close the game.
2. Back up the entire SaveGames folder before replacing any file.
3. Open %LOCALAPPDATA%\KoeiTecmo\DW3CE_RE\Saved\SaveGames.
4. Copy this package's GameStatusData.sav into that folder. Preserve the other files.
5. Keep this game's Steam Cloud sync disabled while testing. Resolve sync conflicts deliberately.
6. Launch the game and verify progress and equipment before saving.

The two modified saves were generated from the included clean initial save. Native and browser outputs match byte for byte. The 100% Perfect save was tested in-game by the project owner with no reported issues. The 101% Overlimit save was tested in-game by the project owner on October 11, 2026, with no reported issues.
Permanent Musou values are preserved. Four-element mixing is not used. No Steam achievements or challenge leaderboard scores are fabricated.

Disclaimer
Unofficial community project, provided as is without warranties. Modifying saves may cause data loss or unexpected behavior. You are responsible for backups and use. This project is not affiliated with or endorsed by KOEI TECMO or Valve. The project code is MIT licensed; the game save and game assets are not relicensed.

Patcher: https://vdustr.github.io/game-save-dw3cer/
Source and acceptance scope: https://github.com/VdustR/game-save-dw3cer

Credits
真三国无双2复刻版强力初始存档最终版 - hanjigang
https://bbs.3dmgame.com/thread-6706994-1-1.html
Universal Koei Tecmo Save Editor - Mexican and contributors
https://github.com/MMexicann/Universal-Koei-Tecmo-Save-Editor
