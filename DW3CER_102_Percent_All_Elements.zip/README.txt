DW3CER Save Patch - 102% All Elements

Windows Steam build 25630985 (executable 1.0.2.0).
The 101% Overlimit profile with all four weapon elements: Fire, Lightning, Steel, Wind.
All 42 officers' fourth and fifth weapons have all four elements. Existing normal
officer weapons also receive all four elements. Officers start with fifth weapons
and five equipped items. Bodyguards use third-tier weapons and Healing Scroll.
Four-element effects vary by situation.
102% is a package label, not a completion meter. Displayed bonuses may exceed
effective combat caps. Permanent Musou is preserved; Steam achievements and
challenge scores are not edited.

Install:
1. Close the game. Back up your SaveGames folder.
2. Extract this ZIP. Replace only GameStatusData.sav in:
   %LOCALAPPDATA%\KoeiTecmo\DW3CE_RE\Saved\SaveGames
3. Keep this game's Steam Cloud sync off while testing.
4. Check your progress and equipment before saving. Restore your backup if needed.

Checks: Native parse/roundtrip, repeat patch, and fourth/fifth weapon coverage.
https://github.com/VdustR/game-save-dw3cer/releases/tag/steam-build-25630985
https://vdustr.github.io/game-save-dw3cer/

Unofficial community project. Provided as is, without warranties.
No affiliation with KOEI TECMO or Valve. Game saves and assets are not relicensed.
